function varargout = assert_exception(varargin)
% VL_ASSERT_EXCEPTION
[varargout{1:nargout}] = vl_assert_exception(varargin{:});
