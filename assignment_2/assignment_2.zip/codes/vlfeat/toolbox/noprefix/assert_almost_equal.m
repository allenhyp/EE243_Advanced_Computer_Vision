function varargout = assert_almost_equal(varargin)
[varargout{1:nargout}] = vl_assert_almost_equal(varargin{:});
